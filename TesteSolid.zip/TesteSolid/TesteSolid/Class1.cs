﻿using System;

namespace TesteSolid
{
    public class Class1
    {
    }
}
