﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TesteSolid.Classes
{
    public class Cliente
    {
        public int idCliente { get; set; }
        public string nome { get; set; }
        public string email { get; set; }
        public string cpf { get; set; }
        public DateTime dataCriacao { get; set; }
    }
}
