﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TesteSolid.Classes
{
    public interface IClienteCadastroServico
    {
        void Cadastrar();
    }
}
