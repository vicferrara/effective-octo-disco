﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TesteSolid.Classes
{
    public interface IClienteRepositorio
    {
        Boolean Insert(Cliente cliente);
    }
}
